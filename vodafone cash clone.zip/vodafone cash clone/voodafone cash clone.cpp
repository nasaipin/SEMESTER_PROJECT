#include <iostream>

using namespace std;

int main() 
{
	string accountName; 
	
	int number;
	int amount;
	int choice, account;
	int pin = 1122, newPin1, newPin2, newPin;
	
	int theNumber;
	double theAmount;
	
	double totalAmount;
			int firstTransanction, secondTransanction, thirdTransanction, fourthTransanction;
			totalAmount = 100;
			double balance = totalAmount - amount;
	// registration and login
	int log;
	cout << "do you have and account already? if yes then enter 1 to login or enter 2 to create one. otherwise enter 9 to exit" << endl;
	log:
		 
	cin >> log;
	
	
	
	
	
	if (log == 1) {
		cout << "login successful" << endl;
	cout << "Please enter your default pin (1122) to log into your account" << endl;
	boss:
	cin >> pin;
		if (pin == 1122)  {
			pius:
				me:
	cout << "WELCOME TO VODAFONE CASH GHANA" << endl;
										 	// case 1: send money and all transaction
	cout << "1. send money\n";				// case 2: withdraw money
	cout << "2. withdraw money\n";			// case 3: buy airtime or data
	cout << "3. Buy airtime or data\n";		
	cout << "4. check balance\n";			// case 4: check balance
	cout << "5. withdraw money / transaction\n";			// case 5: pin settings
	cout << "6. pin settings\n";			// case 7: 
	cout << "9. exit\n";
	cin >> choice;
	
	

	switch (choice) {
		// this should be send and recieve money 
		
		// this should be withdrawal of money
case 1:
			send:
			cout << "FINANCIAL transaction" << endl;
			cout << "1. send money\n";
			
			cin >> choice;
			if (choice == 1) {
			cout << "Please choose one of the following options" << endl;
			cout << "1. same network\n";
			cout << "2. other networks\n";
			cout << "0. go back\n";	
			cout << "9. exit\n";	
			cin >> choice;
			if (choice == 1) {
				cout << "Please enter the number to sent the money to" << endl;
				cin >> number;
				cout << "Please enter the amount " << endl;
				cin >> amount;
				cout << "Please enter your pin" << endl;
				cin >> pin;
				cout << "you have sent " << amount << " to " << number << " and your current balance is " << balance << endl;
		
			}
				else if (choice == 2) {
				cout << "Please select the network" << endl;
				cout << "1. MTN\n";
				cout << "2. AirtelTigo\n";
				cin >> choice;
			
				// to MTN number
				if (choice == 1) {
					double amount1, amount2;
					cout << "Please enter the MTN number" << endl;
					cin >> number;
					cout << "Please the amount" << endl;
					cin >> amount;
					cout << "Please enter your pin" << endl;
					cin >> pin;
					cout << "you have sent " << amount << " to " << number << endl;		
					}
					// to AirtelTigo network
					if (choice == 2) {
						cout << "Please enter the AirtelTigo number" << endl;
					cin >> number;
					cout << "Please the amount" << endl;
					cin >> amount;
					cout << "Please enter your pin" << endl;
					cin >> pin;
					cout << "you have sent " << amount << " to " << number << endl;
					}
			}
			else if (choice == 0) {
				cout << "back to the previous menu" << endl;
				goto pius;
			}
			else if (choice == 9) {
				cout << "you have exitted the process" << endl;
				goto last;
			}
			else {
				cout << "invalid number" << endl;
			}
			}
			else {
				cout << "Invalid number please try again" << endl;
				goto send;
			}
		
			
				
			 
			
			
			
		
			break;
			
		// buy airtime or data
case 2:
				cout << "WITHDRAW MONEY" << endl; 
	        	cout << "Please enter the agents number" << endl; 
				cin >> number; 
				cout << "Please enter the amount you want to withdraw" << endl;
				cin >> amount;
				cout << "Please enter your pin" << endl;
				cin >> pin;
				cout << "CONGRATS, you have successfully withdrawn " << amount << endl;  
				break;
		// this should be financial service
case 3:
			cout << "airtime and Data" << endl;
			cout << "1. self\n";
			cout << "2. other\n";
			cin >> choice;
			if (choice == 1) {
				cout << "1. airtime\n";
				cout << "2. Data\n";
				cin >> choice;
				if (choice == 1) {
					cout << "Please enter the amount" << endl;
					cin >> amount;
					cout << "Please enter your pin" << endl;
					cin >> pin;
					cout << "CONGRATS you have successfully bought airtime worth " << amount << " for your self" << endl;
				
				}
				else if (choice == 2) {
			 		cout << "Please enter the amount" << endl;
					cin >> amount;
					cout << "Please enter your pin" << endl;
					cin >> pin;
					cout << "CONGRATS you have successfully bought data worth " << amount << " for your" << endl;
				
				}
				else if (choice == 0) {
				cout << "back to the previous menu" << endl;
				goto pius;
			}
			else if (choice == 9) {
				cout << "you have exitted the process" << endl;
				goto last; }
				else {
				cout << "Invalid number" << endl;
				}
			}
			else if (choice == 2) { 
				cout << "1. airtime\n";
				cout << "2. data\n";
				cin >> choice;
				if (choice == 1) {
					cout << "Please enter the number" << endl;
					cin >> number;
					cout << "Please enter the amount" << endl;
					cin >> amount;
					cout << "Please enter your pin" << endl;
					cin >> pin;
					cout << "CONGRATS you have successfully bought airtime worth " << amount << " for " << number << endl;
				}
				else if (choice == 2) {
					cout << "Please enter the number" << endl;
			 		cin >> number;
			 		cout << "Please enter the amount" << endl;
					cin >> amount;
					cout << "Please enter your pin" << endl;
					cin >> pin;
					cout << "CONGRATS you have successfully bought data worth " << amount << " for " << number << endl;
				
				}
				else if (choice == 0) {
				cout << "back to the previous menu" << endl;
				goto pius;
			}
			else if (choice == 9) {
				cout << "you have exitted the process" << endl;
				goto last;}
				else {
				cout << "invalid number" << endl;
			}
			}
			else {
				cout << "invalid number" << endl;
			}
			break;
		
case 4:
		double totalAmount;
		totalAmount = 100;	
		cout << "CHECK BALANCE" << endl;
		cout << "Please enter your pin" << endl;
		
		cin >> pin;
		if (pin == 1122) {
			cout << "your balance is " << totalAmount << endl;
		}
		else {
			cout << "wrong Pin entered, Please enter the pin again" << endl;
			
		}
		
case 5: 
			double newAmount;
			totalAmount = 100;
			balance = totalAmount - theAmount;
			cout << "WITHDRAW MONEY" << endl;
			cout << "Please enter the agent serial number" << endl;
			cin >> pin; 
			cout << "Please enter the amount you want to withdraw" << endl;
			cin >> theAmount;
			newAmount = totalAmount - amount;
			cout << "you have successfull withdrawn " << theAmount << " and your current balance is " << balance << endl;	
		
		
			cout << "YOUR TRANSACTION HISTORY" << endl;
				cout << "your total balance was " << totalAmount << endl;
				
				firstTransanction = totalAmount - theAmount;
				cout << "your first transaction worthed: " << theAmount << " and your current balance is: " << firstTransanction << endl;
				secondTransanction = firstTransanction - theAmount;
				cout << "your secong transaction worthed: " << theAmount << " and your current balance is: " << secondTransanction << endl;
				thirdTransanction = secondTransanction - theAmount;
				cout << "your third transaction worthed: " << theAmount << " and your current balance is : " << thirdTransanction << endl;
				cout << "your current balance is " << thirdTransanction << endl;
		
	case 6:
			cout << "CHANGE PIN" << endl;
			cout << "Please enter your default pin" << endl;
			cin >> pin;
			pin:
			cout << "Please enter your new pin" << endl;
			cin >> newPin;
			cout << "Please enter the new pin again" << endl;
			cin >> newPin1;
			if (newPin == newPin1) {
				cout << "Pin successfully reset" << endl;
			}
			else if (newPin == pin) {
				cout << "Please enter your new pin" << endl;
				goto pin;
			}
			else {
				cout << "Invalid pin" << endl;
				goto pin;
			}
			
			break;
					
	default: {
		cout << "Invalid number" << endl;
		break;
	}
	}
	}
	else { cout << "Invaid pin please enter again" << endl;
	goto boss;
	}
	last:
		cout << "Thank you for your time with us, we wish to see you soon" << endl;
	
		
		
	}
	else if (log == 2 ) {
		string name;
		int number, pin1, pin2, id;
		cout << "we are here to create an account for you" << endl;
		
		
		cout << "Please enter your full names" << endl;
		cin >> name;
		getline (cin, name);
		cout << "Please enter your ID number" << endl;
		cin >> id;
		cout << "Please enter your phone number" << endl;
		cin >> number;
		enter:
		cout << "Please choose a four digit pin" << endl;
		cin >> pin1;
		cout << "Please enter your pin again" << endl;
		cin >> pin2;
		if (pin1 == pin2) {
				cout << "your accout is successfully created with name: " << name << " and: " << number << endl; 
				// this one is taking you back to your acoount
				cout << "Please enter a number 1 to login or 9 to exit" << endl;
				cin >> number;
				if (number == 1) {
					cout << "login successful" << endl;
					goto me;
				}
				else if (number == 9) {
					cout << "you have exitted the program" << endl;
					goto last;
				}
				else {
					cout << "invalid number entered" << endl;
					
				}
				
				
		}
		else {
			cout << "pin mismatched please enter pin again" << endl;
			goto enter;
		 
		}
			
	
		
	}
	else if (log == 9 ) {
		cout << "you have exitted the program" << endl;
		goto last;
	}
	else {
		cout << "invalid number entered please enter a number again" << endl;
		goto log;
	}
	
	
	
	return 0;
}
